# Project : Classification II | Foundations of Modern Machine Learning Project

This mini-project tries to solve the computer-vision task of identifying the 
number of fingers held up in front of a camera using fundamental and basic ML
Algorithms. The intent is to explain and teach the pros and cons of learning 
algorithms like Decision Trees, Random Forests, Support Vector Machines, et 
cetera. This repo is a part of the course offered by iHub, IIIT Hyderabad : 
Foundations of Modern Machine Learning.
